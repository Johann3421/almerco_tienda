<div class="table">
<?php echo e(Illuminate\Mail\Markdown::parse($slot)); ?>

</div>
<?php /**PATH C:\xampp\htdocs\tienda-grupo-almerco-main\resources\views/vendor/mail/html/table.blade.php ENDPATH**/ ?>