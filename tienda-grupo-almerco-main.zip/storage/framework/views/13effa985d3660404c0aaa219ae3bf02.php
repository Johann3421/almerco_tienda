<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\xampp\htdocs\tienda-grupo-almerco-main\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>