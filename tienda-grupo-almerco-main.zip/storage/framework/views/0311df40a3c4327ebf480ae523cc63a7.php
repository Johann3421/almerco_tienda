<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\tienda-grupo-almerco-main\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>