<script setup>
import Products from '@/Layouts/Web/Products/Products.vue';
</script>

<template>
    <main class="mt-15">

        <Products />
    </main>
</template>
