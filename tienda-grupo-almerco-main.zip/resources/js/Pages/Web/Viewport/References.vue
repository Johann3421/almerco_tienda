<template>
    <!-- Sección de referencias -->
    <section class="bg-gradient-to-b from-sky-900 to-sky-500 overflow-hidden py-4 mt-12">
        <div class="mx-auto px-4 py-8 sm:px-6 sm:py-12 lg:px-8 lg:py-16">
            <div class="mx-auto max-w-lg text-center">
                <h2 class="text-3xl font-bold sm:text-4xl text-white">¿Por qué comprar en SEKAI TECH?</h2>
            </div>

            <ul class="mt-4 grid grid-cols-1 md:grid-cols-2 lg:flex lg:gap-1 lg:justify-center text-white">

                <li class="block rounded-xl p-6 transition text-center lg:w-64">
                    <i class="mdi mdi-store text-8xl border-white rounded-full py-1 px-3 bg-sky-700"></i>
                    <h2 class="mt-8 text-lg font-bold text-white">Recoge en tienda tu compra online</h2>
                </li>

                <li class="block rounded-xl p-6 transition text-center lg:w-64">
                    <i class="mdi mdi-lifebuoy text-8xl border-white rounded-full py-1 px-3 bg-sky-700"></i>
                    <h2 class="mt-8 text-lg font-bold text-white">Brindamos soporte de garantía en tus compras</h2>
                </li>

                <li class="block rounded-xl p-6 transition text-center lg:w-64">
                    <i class="mdi mdi-account-tie text-8xl border-white rounded-full py-1 px-3 bg-sky-700"></i>
                    <h2 class="mt-8 text-lg font-bold text-white">Te asignamos un ejecutivo de ventas</h2>
                </li>

                <li class="block rounded-xl p-6 transition text-center lg:w-64">
                    <i class="mdi mdi-truck-delivery text-8xl border-white rounded-full py-1 px-3 bg-sky-700"></i>
                    <h2 class="mt-8 text-lg font-bold text-white">Ofrecemos delivery y envío en todo el Perú</h2>
                </li>
            </ul>
        </div>
    </section>
    <!-- Finalizar referencias -->
</template>